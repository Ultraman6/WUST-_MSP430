#ifndef _SEG_H
#define _SEG_H

#include <reg52.h>
#include "main.h"

extern u8 segBuff[];

void SegShow();

#endif