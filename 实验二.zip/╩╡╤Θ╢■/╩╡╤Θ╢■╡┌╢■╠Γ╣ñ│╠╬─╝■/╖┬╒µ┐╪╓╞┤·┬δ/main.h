#ifndef _MAIN_H
#define _MAIN_H

#define u8  unsigned char  
#define u16 unsigned char  
	
#endif