#include <reg51.h>
unsigned char code LED[]={0xc0,0xf9,0xa4,0xb0,0x99,0x92,0x82,0xf8,0x80,0x90};
unsigned char m,buf[4];
unsigned int shu,j;
void delay(unsigned char x)
{
	unsigned char y;
	for(;x>0;x--)
		for(y=110;y>0;y--);					
}
void dis(unsigned int temp)
{
	unsigned char i;
	buf[0]=0;
	buf[1]=0;
	buf[2]=temp/10;
	buf[3]=temp%10;
	
	for(i=0;i<4;i++)
	{
		P2=(0x01<<i);
		P1=LED[buf[i]];
		delay(5);
		P1=0xff;
	}
}

void INT_0( ) interrupt 0 
{	
	TR0=~TR0;
}
void INT_1( ) interrupt 2 
{	
	TR0=~TR0;
	TL0=(65536-50000)%256;	
    TH0=(65536-50000)/256;
	shu=60;
    j=0; 
          	
}
void TIME_0( ) interrupt 1
{
    TL0=(65536-50000)%256;	
    TH0=(65536-50000)/256;			
    j++;
	if(j==20)
	{
	    j=0;
		shu--;
		if(shu==0)
		TR0=0;
	}
}
void main()
{       
    TCON=0x05;
    IP=0x00;
    TMOD=0x01;
    TL0=(65536-50000)%256;	
    TH0=(65536-50000)/256;	
    TR0=1;
    IE=0x87;
    shu=60;
    j=1;
	while(1)
	{
		dis(shu);
	}		
}
