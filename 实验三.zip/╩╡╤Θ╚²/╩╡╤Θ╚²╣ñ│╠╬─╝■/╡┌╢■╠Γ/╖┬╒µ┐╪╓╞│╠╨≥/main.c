#include <reg51.h>
#define uchar unsigned char
#define uint unsigned int
sbit P1_0 =P1^0;
sbit P1_1 =P1^1;
sbit P1_2 =P1^2;
sbit P1_3 =P1^3;
sbit sn_red=P0^0;
sbit sn__yellow=P0^1;
sbit sn__green=P0^2; 
sbit ew_red=P0^3;
sbit ew__yellow=P0^4;
sbit ew_green=P0^5;


uchar code s7_table[]={0x3f,0x06,0x5b,0x4f,0x66,0x6d,0x7d,0x07,0x7f,0x6f};
uchar time=13;
uchar timex=13;
uchar time_flag;
uchar timex_flag;
uchar led_change;
uchar led_change1;
uchar yellow_led_flag;
void delay_ms(uchar z) 
{
    uchar i,j;
	for(i=z;i>0;i--)
	    for(j=110;j>0;j--);
}
void display_time()
{
	P1_0=0;P1_1=1;P1_2=1;P1_3=1;
	P2=s7_table[timex/10];
	delay_ms(2);
	P2=0;
	P1_0=1;
   	
	P1_1=0;
	P2=s7_table[timex%10];
	delay_ms(2);
	P2=0;
	P1_1=1;

	P1_2=0;
	P2=s7_table[time/10];
	delay_ms(2);
	P2=0;
	P1_2=1;

	P1_3=0;
	P2=s7_table[time%10];
	delay_ms(2);
	P2=0;
	P1_3=1;
}	
void init0_timer()
{
	TMOD=0X01;
	TH0=(65536-50000)/256;
	TL0=(65536-50000)%256;
	ET0=1;
	EA=1;
	TR0=1;
}
void south_north_allow()
{
	ew_red=0;
	ew_green=1;
	ew__yellow=1;
	sn_red=1;
	sn__green=0;
	sn__yellow=1;
}
void earth_west_allow()
{
	ew_red=1;
	ew_green=0;
	ew__yellow=1;
	sn_red=0;
	sn__green=1;
	sn__yellow=1;
}  
void main()
{
  init0_timer();
	ew_red=1;
	ew_green=0;
	ew__yellow=1;
	sn_red=0;
	sn__green=1;
	sn__yellow=1;
	yellow_led_flag=2;
	while(1)
	{
		display_time();
	}
}
void_int0_isr() interrupt 1
{
	TH0=(65536-50000)/256;
	TL0=(65536-50000)%256;
	time_flag++;
	timex_flag++;
	if(time_flag==20||timex_flag==20)
	{
		time_flag=0;
		timex_flag=0;
		if(time==0)
		{
			time=13;
			if(key_sn_add==0)
			{
				time++;
			}
			if(key_sn_sub==0)
			{
				time--;
			}
			led_change++;
			if(led_change==1)
			{
				sn_red=0;
				sn__green=1;
				ew_red=0;
				ew_green=1;
				ew__yellow=1;
				sn__yellow=1;
				yellow_led_flag=1;
			}
			if(led_change==2)
			{
				led_change=0;
				ew_red=1;
				ew_green=0;
				sn_red=1;
				sn__green=1;
				ew__yellow=1;
				sn__yellow=0;
				yellow_led_flag=2;
			}	  
		}
		else
		{
			time--;
		}
	if(time==3)
		{
			if(yellow_led_flag==2)
			{
				ew_red=1;
				ew_green=1;
				sn_red=0;
				sn__green=1;
				ew__yellow=0;
				sn__yellow=1;
			}  
		}	


		if(timex==0)
		{
			timex=13;
			if(key_ew_add==0)
			{
				timex++;
			}
			if(key_ew_sub==0)
			{
				timex--;
			}
		 	led_change1++;
			if(led_change1==1)
			{	
				sn_red=1;
				sn__green=0;
				ew_red=0;
				ew_green=1;
				ew__yellow=1;
				sn__yellow=1;
				yellow_led_flag=1;	 
			}	
			if(led_change1==2)
			{
				led_change1=0;
				ew_red=1;
				ew_green=0;
				ew__yellow=1;
				sn_red=0;
				sn__green=1;
				sn__yellow=1;
				yellow_led_flag=2;
			}	 
		}
		else
		{
			timex--;
		}
		if(timex==3)
		{
		    if(yellow_led_flag==1)
			{
			  ew_red=0;
				ew_green=1;
				sn_red=1;
				sn__green=1;
				ew__yellow=1;
				sn__yellow=0;
			}
		}
	}
}