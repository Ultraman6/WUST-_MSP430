#include<reg51.h>
sbit LED_L=P1^0;
sbit LED_R=P1^1;
sbit S_L=P3^0;
sbit S_R=P3^1;
void delay(unsigned int i)
{
   unsigned int k;
   for(k=0;k<i;k++);

}
void main()
{
  bit left,right;
  while(1)
  {
     left=S_L;
	 right=S_R;
	 LED_L=left;
	 LED_R=right;
	 delay(20000);
	 LED_L=1;
	 LED_R=1;
	 delay(20000);
  
  }
}