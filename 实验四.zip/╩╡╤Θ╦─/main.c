#include <msp430.h>
#include "stdint.h"
#include "HAL_UCS.h"
/* Private define ------------------------------------------------------------*/
#define NumOfResult 8
#define Max_Volt 3.3
#define Accu_Adc 4095
uint32_t results[NumOfResult+1];
uint16_t average;
uint16_t index = 0;
#define XT2_PORT_SEL P7SEL
#define XT2_ENABLE (BIT2+BIT3)
// LCD segment definitions.
#define d 0x01
#define c 0x20
#define b 0x40
#define a 0x80
#define dp 0x10
#define g 0x04
#define f 0x08
#define e 0x02

uint8_t con[10] , trans_v[10];
const char char_gen[] = { // As used in 430 Day Watch Demo board
 a+b+c+d+e+f, // Displays "0"
 b+c, // Displays "1"
 a+b+d+e+g, // Displays "2"
 a+b+c+d+g, // Displays "3"
 b+c+f+g, // Displays "4"
 a+c+d+f+g, // Displays "5"
 a+c+d+e+f+g, // Displays "6"
 a+b+c, // Displays "7"
 a+b+c+d+e+f+g, // Displays "8"
 a+b+c+d+f+g, // Displays "9"
 a+b+c+e+f+g, // Displays "A"
 c+d+e+f+g, // Displays "b"
 a+d+e+f, // Displays "c"
 b+c+d+e+g, // Displays "d"
 a+d+e+f+g, // Displays "E"
 a+e+f+g, // Displays "f"
 a+b+c+d+f+g, // Displays "g"
 c+e+f+g, // Displays "h"
 b+c, // Displays "i"
 b+c+d, // Displays "j"
 b+c+e+f+g, // Displays "k"
 d+e+f, // Displays "L"
 a+b+c+e+f, // Displays "n"
 a+b+c+d+e+f+g+dp // Displays "full"
};
const char char_gen_dp[] = { // As used in 430 Day Watch Demo board
 a+b+c+d+e+f+dp, // Displays "0"
 b+c+dp, // Displays "1"
 a+b+d+e+g+dp, // Displays "2"
 a+b+c+d+g+dp, // Displays "3"
 b+c+f+g+dp, // Displays "4"
 a+c+d+f+g+dp, // Displays "5"
 a+c+d+e+f+g+dp, // Displays "6"
 a+b+c+dp, // Displays "7"
 a+b+c+d+e+f+g+dp, // Displays "8"
 a+b+c+d+f+g+dp, // Displays "9"
 a+b+c+e+f+g, // Displays "A"
 c+d+e+f+g, // Displays "b"
 a+d+e+f, // Displays "c"
 b+c+d+e+g, // Displays "d"
 a+d+e+f+g, // Displays "E"
 a+e+f+g, // Displays "f"
 a+b+c+d+f+g, // Displays "g"
 c+e+f+g, // Displays "h"
 b+c, // Displays "i"
 b+c+d, // Displays "j"
 b+c+e+f+g, // Displays "k"
 d+e+f, // Displays "L"
 a+b+c+e+f, // Displays "n"
 g, // Displays "-"
 dp, // Displays "dp"
 a+b+c+d+e+f+g+dp // Displays "full"
};
/* Private functions ---------------------------------------------------------*/
/*!
*�������ܣ�����LCD segment output����
*�����������
*����ֵ�� ��
*/
void Init_lcd(void)
{
 LCDBCTL0 =LCDDIV0 + LCDPRE0 + LCDMX1 + LCDSSEL + LCDMX1 + LCD4MUX ;
 LCDBPCTL0 = LCDS0 + LCDS1 + LCDS2 + LCDS3 + LCDS4 + LCDS5 + LCDS6+ LCDS7 +LCDS8+ LCDS9 + LCDS10 + LCDS11 ;
 P5SEL = 0xfc;
}
/*****************************************************************************
�򿪻�ر�Һ��
1���� 0���ر�
*****************************************************************************/
void LcdGo(unsigned char doit)
{
if(doit==1)
{
//��Һ����ʾ
LCDBCTL0 |= LCDON;
}
else if(doit==0)
{
//�ر�Һ����ʾ
LCDBCTL0 &= ~LCDON;
}
}
/***************************************************************************
��ʾ����������ʾ����
doit��0������ 1����ʾ
****************************************************************************/
void LcdBlink(unsigned char doit)
{
if(doit==0)
{
LCDBCTL0 &= ~LCDSON;
}
else if(doit==1)
{
LCDBCTL0 |= LCDSON;
}
}
void LCD_Clear(void)//����
{
unsigned char index;
for (index=0; index<12; index++)
{
LCDMEM[index] = 0;
}
}
/*port function select*/
void Init_TS3A5017DR(void)
{
// Configure TS3A5017DR IN1 and IN2
P1DIR |= BIT6 + BIT7; //P3.4 : IN1 ; P3.5 : IN2 set as output
P1OUT &= ~BIT7; //IN1 = 0
P1OUT |= BIT6; //IN2 = 1
}
/*!
*�������ܣ�LCD segment ����ʹ��
*�����������
*����ֵ�� ��
*/
void Backlight_Enable(void)
{
P8DIR |= BIT0;
P8OUT |= BIT0;
}
int16_t Trans_val(uint16_t number,uint16_t system, uint8_t *output)
{
 // ��,�����ͱ��
int16_t Quotient, Balance, i = 0, j , k;
 int32_t caltmp;
 uint16_t Curr_Volt;
 caltmp = number;
 caltmp = (caltmp << 5) + number; //caltmp = Hex_Val * 33
 caltmp = (caltmp << 6) + (caltmp << 5) + (caltmp << 1); //caltmp = caltmp * 100
 Curr_Volt = caltmp >> 12; //Curr_Volt = caltmp / 2^n=4096
 Quotient = Curr_Volt;
 do
 {
 Balance = Quotient % system;
 output[i++] = Balance;
 } while (Quotient /= system);
 // ת��Ϊchar��
 for(j = 0; j < i; j++)
 if(output[j] > 9)
 output[j] = output[j] + 55;
 else output[j] += 48;
 // �ַ���ȡ��
 for(k = 0; k < i / 2; k++)
 {
 char tmp;
 tmp = output[k];
 output[k] = output[i - k - 1];
 output[i - k - 1] = tmp;
 }
 return i;
}
int16_t Conversion(uint16_t number,uint16_t system, uint8_t *output)
{
 // ��,�����ͱ��
int16_t Quotient, Balance, i = 0,j ,k;
 Quotient = number;
 do
 {
 Balance = Quotient % system;
 output[i++] = Balance;
 } while (Quotient /= system);
 // ת��Ϊchar��
 for(j = 0; j < i; j++)
 if(output[j] > 9)
 output[j] = output[j] + 55;
 else output[j] += 48;
 // �ַ���ȡ��
 for(k = 0; k < i / 2; k++)
 {
 char tmp;
 tmp = output[k];
 output[k] = output[i - k - 1];
 output[i - k - 1] = tmp;
 }
 return i;
}
void main(void)
{A
WDTCTL = WDTPW+WDTHOLD; // Stop watchdog timer
Init_TS3A5017DR(); // Configure TS3A5017DR IN1 and IN2
Init_lcd(); // lcd��ʼ��
LcdGo(1); // ��Һ��ģ��
LCD_Clear(); //����
Backlight_Enable();
P6SEL |= BIT6; // Enable A/D channel
ADC12CTL0 = ADC12ON+ADC12SHT0_15+ADC12MSC ; // Turn on ADC12, set sampling time
 // set multiple sample conversion
ADC12CTL1 = ADC12SHP + ADC12CONSEQ_2 + ADC12SSEL_1; // Use sampling timer, set mode ,set clock ACLK
ADC12MCTL0 |= ADC12INCH_6; //change
ADC12IE = ADC12IE0; // Enable ADC12IFG.0
ADC12CTL0 |= ADC12ENC; // Enable conversions
ADC12CTL0 |= ADC12SC; // Start conversion
_EINT(); // Enable all interrupt
_BIS_SR(LPM4_bits + GIE); // Enter LPM4, Enable interrupts
__no_operation(); // For debugger
}
#pragma vector=ADC12_VECTOR
__interrupt void ADC12ISR (void)
{
results[index++] = ADC12MEM0; // Move results
if(index == NumOfResult)
{
uint16_t i;
average = 0;
for(i = 0; i < NumOfResult; i++)
{
average += results[i];
results[i] = 0;
}
average >>= 3; //����8
Conversion(average , 10, con);
Trans_val(average , 10, trans_v);
index = 0;
LCDMEM[5] = char_gen[con[3]-48];
LCDMEM[4] = char_gen[con[2]-48];
LCDMEM[3] = char_gen[con[1]-48];
LCDMEM[2] = char_gen[con[0]-48];
for(i=0;i < NumOfResult;i++)
{
con[i] = 0 ;
trans_v[i] = 0;
}
}
}
